# GÖREV Kurulum Rehberi
v1.0 · 2026-07-10 · Terminal gerekmez, her şey GitHub web arayüzünden.

## Ne kuruyorsun
- **index.html** = site (Focus Mode, kazı-kazan, takip)
- **fetch_jobs.py** = veri motoru (ilanları çeker)
- **.github/workflows/gorev.yml** = zamanlayıcı (hafta içi 06:00 TR'de motoru çalıştırır)
- **data/jobs.json** = motorun yazdığı ilan dosyası (seed hali boş)

## Adım 1: Repo oluştur (2 dk)
1. github.com > sağ üst **+** > **New repository**
2. İsim: `gorev` (veya mevcut dashboard repo'nu kullan)
3. **Public** seç (GitHub Pages ücretsiz olması için), **Create repository**

## Adım 2: Dosyaları yükle (3 dk)
1. Repo sayfasında **Add file > Upload files**
2. Zip'ten çıkan HER ŞEYİ klasör yapısıyla sürükle bırak
   - Önemli: `.github/workflows/gorev.yml` klasör yoluyla gitmeli. Sürükle-bırak klasörü korur.
   - Görünmüyorsa: **Add file > Create new file**, dosya adına `.github/workflows/gorev.yml` yaz (eğik çizgiler klasör oluşturur), içeriği yapıştır.
3. **Commit changes**

## Adım 3: GitHub Pages'i aç (1 dk)
1. Repo > **Settings > Pages**
2. Source: **Deploy from a branch**, Branch: **main**, klasör: **/ (root)** > Save
3. 1-2 dk sonra adres: `https://KULLANICIADIN.github.io/gorev/`
4. Bu adresi telefonda Safari/Chrome'dan aç > paylaş menüsü > **Ana ekrana ekle**. Artık uygulama gibi.

## Adım 4: Actions iznini aç (1 dk)
1. Repo > **Settings > Actions > General**
2. En altta **Workflow permissions** > **Read and write permissions** seç > Save
   (Motor jobs.json'u repoya geri yazabilsin diye gerekli.)

## Adım 5: Motoru ilk kez elle çalıştır (1 dk)
1. Repo > **Actions** sekmesi > soldan **gorev-veri-motoru** > **Run workflow**
2. 1-2 dk sonra yeşil tik. data/jobs.json dolmuş olmalı.
3. Siteyi yenile: ilanlar Görev 1'de kart olarak gelir.
4. Kırmızı çarpı görürsen: log'a tıkla, hata satırını bana yapıştır, düzeltirim.

## Adım 6 (opsiyonel): Telefon bildirimi
1. Telefona **ntfy** uygulamasını kur (ücretsiz, App Store'da var)
2. Uygulamada bir topic'e abone ol. Tahmin edilemez bir isim seç: örn `burcu-gorev-x7k2`
3. Repo > **Settings > Secrets and variables > Actions > Variables** sekmesi > **New repository variable**
   - Name: `NTFY_TOPIC` · Value: `burcu-gorev-x7k2`
4. Artık her sabah motor çalışınca telefona bildirim düşer. Salı sabahı özel mesaj gelir (en verimli başvuru penceresi).

## Adım 7 (opsiyonel): CV dosyaları
Repo'da `cv/` klasörü aç, 5 CV'nin son sürümlerini şu adlarla koy:
`CV1_BD.docx, CV2_KAM.docx, CV3_Master.docx, CV4_Insights.docx, CV5_Commercial_Project.docx`
Sitedeki CV'ler sekmesindeki linkler çalışmaya başlar.
Not: Public repo'da dosyalar herkese açık olur. İstemiyorsan bu adımı atla, CV'ler telefonunda kalsın.

## Bakım
- **Karaliste:** Sitede anında çalışır. Motorun da görmesi için fetch_jobs.py içindeki `"blacklist"` satırına şirketi ekle (GitHub'da dosyaya tıkla > kalem ikonu > düzenle > commit).
- **Şirket kariyer sitesi ekleme:** fetch_jobs.py içindeki `greenhouse_boards` ve `lever_companies` listelerine token ekle. Hangi şirket hangi ATS'de bilmiyorsan bana sor, birlikte bakarız.
- **hiring.cafe kırılırsa:** Site otomatik link moduna düşer, sen fark etmezsin, bana "motor kırıldı" de yeter.

## Bilinen sınırlar (dürüstlük köşesi)
- hiring.cafe API'si resmi değil; ayda bir format değişebilir. Kırılganlık normaldir, tamiri 10 dakikadır.
- LinkedIn otomatik çekilemez (teknik + kural engeli). Görev 3'teki tek tık linkler bu iş için var.
- Veriler telefonun tarayıcısında saklanır (localStorage). Tarayıcı verisini silersen seri sıfırlanır. Ayarlar > "Durumu dışa aktar" ile ara sıra yedek al.
